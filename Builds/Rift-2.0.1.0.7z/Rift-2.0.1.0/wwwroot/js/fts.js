﻿window.rift.fts = {
    animations: {
        welcome: async function () {
            const riftAnimation = anime({
                targets: [`#fts-welcome .image img`],
                opacity: ['0%', '100%'],
                scale: [0, 1],
                delay: anime.stagger(100, {start: 200})
            }).finished;
            const textAnimation = anime({
                targets: [`#fts-welcome .text h1`, `#fts-welcome .text h3`],
                opacity: ['0%', '100%'],
                translateY: [20, 0],
                delay: anime.stagger(1000, {start: 200})
            }).finished;

            await Promise.all([riftAnimation, textAnimation]);
        },
        welcomeOut: async function() {
            const outAnimation = anime({
                targets: [`#fts-welcome .image`, `#fts-welcome .text`],
                opacity: ['100%', '0%'],
                translateY: [0, -30],
                duration: 150,
                easing: 'easeInQuad',
                delay: anime.stagger(50, {start: 1000})
            }).finished;

            await Promise.all([outAnimation]);
        },
        tabOut: async function(tab) {
            const outAnimation = anime({
                targets: [`#fts-${tab} .text`, `#fts-${tab} .content`],
                opacity: ['100%', '0%'],
                translateY: [0, -30],
                duration: 150,
                easing: 'easeInQuad',
                delay: anime.stagger(50)
            }).finished;

            await Promise.all([outAnimation]);
        },
        tabIn: async function(tab) {
            const inAnimation = anime({
                targets: [`#fts-${tab} .text`, `#fts-${tab} .content`],
                opacity: ['0%', '100%'],
                translateY: [30, 0],
                delay: anime.stagger(50)
            }).finished;

            await Promise.all([inAnimation]);
        }
    },
    steps: {
        step: -1,
        steps: ["name", "build"],
        nextStep: async function(button) {
            if(button && button.classList.contains("disabled"))
                return;
            
            this.step++;
            
            if(this.step > 0) {
                let oldId = `${this.steps[this.step - 1]}`;
                let oldTab = document.getElementById(`fts-${oldId}`);
                await rift.fts.animations.tabOut(oldId);
                oldTab.style.display = "none";
            }

            let newId = `${this.steps[this.step]}`;
            let newTab = document.getElementById(`fts-${newId}`);
            newTab.style.display = "flex";
            await rift.fts.animations.tabIn(newId);
        },
        finalIn: async function() {
            await rift.fts.animations.tabOut(this.steps[this.step]);

            let newTab = document.getElementById(`fts-final`);
            newTab.style.display = "flex";
            
            await rift.fts.animations.tabIn("final");
        },
        finalOut: async function() {
            await rift.fts.animations.tabOut("final");
            window.location.reload();
        }
    },
    utils: {
        validateBtn: function(inputField, buttonId, maxLength = 2000, allowSpaces = false) {
            let button = document.getElementById(buttonId);

            if(inputField.value.length > 0 && (!inputField.value.includes(" ") || allowSpaces) && inputField.value.length <= maxLength) {
                if(button.classList.contains("disabled"))
                    button.classList.remove("disabled");
            } 
            else {
                if(!button.classList.contains("disabled"))
                    button.classList.add("disabled");
            }
        }
    }
}

rift.fts.animations.welcome().then(() => {
    rift.fts.animations.welcomeOut().then(() => {
        rift.fts.steps.nextStep();
    });
});
