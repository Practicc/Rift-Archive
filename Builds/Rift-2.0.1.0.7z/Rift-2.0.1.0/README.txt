Thanks for using Rift!
Before using the launcher, be sure you have .NET Core 3.1 runtimes and Microsoft Edge WebView 2 installed.
If you don't have these installed, don't panic, the launcher will guide you to installing them.

Made with ❤️ by the Rift team