﻿window.rift.modsMenu = {
    currentTab: "library",
    showBackBar: function(show) {
        let backBar = document.querySelector(".back-bar");
        let mainHeader = document.querySelector(".main-header");
        
        if(show === true) {
            backBar.classList.remove("hidden");
            mainHeader.classList.add("hidden");
        }
        else {
            backBar.classList.add("hidden");
            mainHeader.classList.remove("hidden");
        }
    },
    setTab: function(tab) {
        let oldPage = document.querySelector(`.tab-container #${this.currentTab}`);
        let newPage = document.querySelector(`.tab-container #${tab}`);
        
        if(!oldPage || !newPage) {
            console.error("that page doesn't exist!");
            return;
        }
        
        let oldPageRadio = document.querySelector(`.header #nav-mtab-${this.currentTab}`);
        let newPageRadio = document.querySelector(`.header #nav-mtab-${tab}`);
        
        oldPageRadio.classList.remove("focus");
        newPageRadio.classList.add("focus");
        
        oldPage.style.display = "none";
        newPage.style.display = "flex";
        this.currentTab = tab;
    }
}